"""

Copyright 2019 European Union

Licensed under the EUPL, Version 1.2 or as soon they will be approved by the European Commission  subsequent versions of the EUPL (the "Licence");

You may not use this work except in compliance with the Licence.
You may obtain a copy of the Licence at:

https://joinup.ec.europa.eu/sites/default/files/inline-files/EUPL%20v1_2%20EN(1).txt

Unless required by applicable law or agreed to in writing, software distributed under the Licence is distributed on an "AS IS" basis,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the Licence for the specific language governing permissions and limitations under the Licence.

"""
from __future__ import absolute_import, print_function

from pcraster.framework import MonteCarloModel
from pcraster.framework import *

from .global_modules.zusatz import DynamicModel
from pcraster import *


class LisfloodModel_monteCarlo(DynamicModel, MonteCarloModel):

    """ LISFLOOD initial part
        same as the PCRaster script -initial-
        this part is to initialize the variables
        it will call the initial part of the hydrological modules
    """

    def __init__(self):
        """ init part of the initial part
            defines the mask map and the outlet points
            initialization of the hydrological modules
        """
        DynamicModel.__init__(self)
        MonteCarloModel.__init__(self)

    def premcloop(self):
        #setrandomseed(42)
        pass
        
        
    def postmcloop(self):
        names = ["dis"]
        #mcaveragevariance(names, self.sampleNumbers(), self.timeSteps())
        #percentiles = [0.1,0.5,0.7,0.9]
        #mcpercentiles(names, percentiles, self.sampleNumbers(), self.timeSteps())
        
